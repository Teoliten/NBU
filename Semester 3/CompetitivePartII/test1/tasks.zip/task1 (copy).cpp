#include <bits/stdc++.h>

using namespace std;

int main()
{
  int a, b, n;
  cin >> a >> b >> n;

    return 0;
}